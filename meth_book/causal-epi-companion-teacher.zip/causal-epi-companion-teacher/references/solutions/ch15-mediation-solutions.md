```{r setup, include=FALSE}
#| cache: false
source("_setup.R")
source("R/simulate_cohort.R")
library(marginaleffects)
set.seed(2024)
```

# Solutions to Chapter 15 exercises {.unnumbered}

::: {.callout-note appearance="simple"}
Worked solutions for the mediation chapter. Self-contained: it rebuilds the cohort
and the chapter's helpers below, so it can be rendered on its own. Not part of the
book build.
:::

```{r recreate}
#| code-fold: false
df <- simulate_cohort(n = 50000, seed = 2024)
df$age_c <- (df$age - 62) / 10          # base assignment keeps the oracle attribute
df$sbp10 <- (df$sbp - 140) / 10         # blood pressure, centred (per 10 mmHg)
o     <- attr(df, "oracle")
truth <- cohort_truth(df)

# the chapter's standardisation helper and the outcome model
standardise <- function(formula) {
  m  <- glm(formula, family = poisson, data = df)
  p1 <- mean(predict(m, mutate(df, drug = 1), type = "response"))
  p0 <- mean(predict(m, mutate(df, drug = 0), type = "response"))
  c(RD = p1 - p0, RR = p1 / p0)
}
out_c <- glm(stroke ~ drug + sbp + severity + age_c + diabetes,
             family = poisson, data = df)
```

## Exercise 1 — watch the path close

Add the confounders one at a time, then add the mediator last, and standardise at
each step.

```{r ex1}
#| code-fold: false
steps <- list(
  "crude (drug only)"    = stroke ~ drug,
  "+ severity"           = stroke ~ drug + severity,
  "+ age"                = stroke ~ drug + severity + age_c,
  "+ diabetes"           = stroke ~ drug + severity + age_c + diabetes,
  "+ blood pressure"     = stroke ~ drug + severity + age_c + diabetes + sbp
)
tibble(model = names(steps)) |>
  bind_cols(map_dfr(steps, standardise)) |>
  kbl(digits = 3, caption = "Standardised risk difference and risk ratio at each step.") |>
  kable_styling(full_width = FALSE)
```

The crude estimate is harmful (RR `r round(standardise(steps[[1]])["RR"], 2)`). The
decisive move towards the truth is **adding `severity`**: it jumps to RR
`r round(standardise(steps[[2]])["RR"], 2)`, already protective. This is the step that
closes the back-door fork `drug <- severity -> stroke` — and the parallel fork through
the mediator, `drug <- severity -> sbp -> stroke` — which is the confounding by
indication that reversed the sign. Adding `age` and `diabetes` refines the estimate
towards the true RR of `r round(truth$ATE_RR, 3)`; these are weaker confounders, so
the movement is small.

Adding **blood pressure** moves the estimate *away* from the total effect, to RR
`r round(standardise(steps[[5]])["RR"], 3)`. Blood pressure is not a confounder; it is
the mediator. Conditioning on it blocks the chain `drug -> sbp -> stroke`, so the
estimate stops counting the protection that flows through blood pressure and reports a
direct effect instead. The first four steps remove bias by closing back-door paths;
the last step introduces a different quantity by closing a front-door (causal) path.
Direction towards the truth is not a reason to keep adjusting — the question is which
*kind* of path each variable lies on.

## Exercise 2 — the cross-world column

```{r ex2}
#| code-fold: false
c(EY00 = mean(o$risk0), EY10 = mean(o$risk_d1m0), EY11 = mean(o$risk1))
```

The cross-world risk `r round(mean(o$risk_d1m0), 4)` lies between the untreated risk
`r round(mean(o$risk0), 4)` and the fully treated risk `r round(mean(o$risk1), 4)`. A
patient contributing to `risk_d1m0` is assumed to be **treated**, so the outcome
receives the drug's direct benefit, while their **blood pressure is held at the value
it would have reached without the drug**, so the outcome receives none of the
mediated benefit. It is therefore protected less than a fully treated patient
(`risk1`) but more than an untreated one (`risk0`).

This number can never come from a contrast of observed groups, because no observed
group is in that state. Patients with `drug = 1` have the blood pressure the drug
*gave* them, not the blood pressure they would have had untreated; patients with
`drug = 0` are not receiving the direct benefit. The quantity needs the *joint*
behaviour of the mediator under one treatment and the outcome under another —
$M(0)$ paired with $Y(1, \cdot)$ — which is never jointly realised in any one person.
It is recoverable only by modelling the mediator and the outcome separately and
recombining them under the four assumptions, never by stratification on observed data.

A caveat: the ordering held here only because the direct and indirect effects share a
sign (both protective). If the drug had a protective indirect effect but a harmful
direct effect, `risk_d1m0` could fall outside the interval bounded by `risk0` and
`risk1`.

## Exercise 3 — break the second assumption deliberately

Keep `severity`, but add an **unmeasured** common cause `U` of blood pressure and
stroke. It raises observed blood pressure by `mU` units and multiplies stroke risk by
`exp(dU)`; the analyst measures neither and so omits it from both models. We rebuild
the outcome coherently from each patient's true factual risk, then run the chapter's
estimator (which never sees `U`).

```{r ex3}
#| code-fold: false
est_nde <- function(data, draws = 50, seed = 1) {        # estimator that omits U
  med <- lm(sbp ~ drug + severity + age_c + diabetes, data = data)
  out <- glm(stroke ~ drug * sbp + severity + age_c + diabetes,   # interaction, as in the DGP
             family = poisson, data = data)
  s <- sigma(med); set.seed(seed)
  mu0 <- predict(med, mutate(data, drug = 0)); mu1 <- predict(med, mutate(data, drug = 1))
  a00 <- a10 <- 0
  for (d in seq_len(draws)) {
    e   <- rnorm(nrow(data), 0, s)
    a00 <- a00 + predict(out, mutate(data, drug = 0, sbp = mu0 + e), type = "response")
    a10 <- a10 + predict(out, mutate(data, drug = 1, sbp = mu0 + e), type = "response")
  }
  mean(a10 / draws) - mean(a00 / draws)
}

set.seed(99)
U  <- rnorm(nrow(df))
rf <- ifelse(df$drug == 1, o$risk1, o$risk0)              # true factual risk per patient
augment <- function(mU, dU) {
  d <- df
  d$sbp    <- df$sbp + mU * U                             # U raises blood pressure
  set.seed(7)
  d$stroke <- rbinom(nrow(df), 1, pmin(rf * exp(dU * U), 0.95))  # U raises stroke risk
  d
}

grid <- expand_grid(mU = c(3, 6), dU = c(0, 0.2, 0.4, 0.6, 0.8, 1.0)) |>
  mutate(est_NDE = map2_dbl(mU, dU, \(m, e) est_nde(augment(m, e))))

grid |>
  pivot_wider(names_from = dU, values_from = est_NDE, names_prefix = "dU=") |>
  kbl(digits = 4, caption = sprintf("Estimated natural direct effect as the hidden confounder strengthens (true NDE stays protective near %.3f throughout).", truth$NDE)) |>
  kable_styling(full_width = FALSE)
```

As `dU` grows, the estimated direct effect rises from protective towards zero and then
turns **positive** — a sign reversal, as in the chapter's hidden-`severity`
demonstration. The mechanism is the collider path `drug -> sbp <- U -> stroke`:
conditioning on blood pressure in the outcome model, with `U` omitted, associates the
drug with `U`, and `U`'s effect on stroke contaminates the direct estimate. The true
direct effect, by construction, stays protective near `r round(truth$NDE, 3)`
throughout, because `U` is independent of the drug and does not alter the drug's causal
effect.

How large an effect flips the sign depends on **both** of `U`'s arrows. With the
weaker blood-pressure link (`mU = 3`) the reversal happens between `dU = 0.6` and
`0.8`; with the stronger link (`mU = 6`) it happens earlier, between `dU = 0.4` and
`0.6`. The stronger the confounder's effect on the mediator, the smaller the effect on
the outcome needed to overturn the conclusion. (The small protective bias already
present at `dU = 0` is a separate, milder artefact: an omitted cause of the mediator
inflates its modelled variance, which shifts the split under the non-linear outcome —
not yet confounding, since at `dU = 0` the variable does not touch the outcome.)

This is the question a **sensitivity analysis** (Chapter 19) makes formal: rather than
assuming no unmeasured mediator-outcome confounding, one asks how strong such a
confounder would have to be — in its joint association with the mediator and the
outcome — to move the estimate to the null or across it. The grid above is a
hand-rolled version of that calculation; the conclusion here is fragile, overturned by
a confounder of moderate strength.

## Exercise 4 — controlled versus natural, with interaction

The controlled direct effect fixes blood pressure at a single value for everyone and
toggles the drug. We read it off the interacted outcome model with `avg_comparisons()`,
standardising over the covariates at each fixed mediator value, and compare against a
model that omits the interaction.

```{r ex4}
#| code-fold: false
out_int_c <- glm(stroke ~ drug * sbp10 + severity + age_c + diabetes,
                 family = poisson, data = df)          # correct, interacted model
out_add_c <- glm(stroke ~ drug + sbp10 + severity + age_c + diabetes,
                 family = poisson, data = df)          # omits the interaction

cde_rr <- function(model, mmHg)
  avg_comparisons(model, variables = "drug", comparison = "ratioavg",
                  newdata = transform(df, sbp10 = (mmHg - 140) / 10))$estimate
cde_rd <- function(model, mmHg)
  avg_comparisons(model, variables = "drug",
                  newdata = transform(df, sbp10 = (mmHg - 140) / 10))$estimate

tibble(
  `sbp (mmHg)`          = c(130, 160),
  `RR (interaction)`    = c(cde_rr(out_int_c, 130), cde_rr(out_int_c, 160)),
  `RR (no interaction)` = c(cde_rr(out_add_c, 130), cde_rr(out_add_c, 160)),
  `RD (interaction)`    = c(cde_rd(out_int_c, 130), cde_rd(out_int_c, 160))
) |>
  kbl(digits = 4, caption = "Controlled direct effect at two fixed blood-pressure values.") |>
  kable_styling(full_width = FALSE)
```

With the `drug:sbp10` term in the model, the controlled direct effect **depends on the
fixed mediator value on the risk-ratio scale**: RR `r round(cde_rr(out_int_c, 130), 3)`
at 130 mmHg against `r round(cde_rr(out_int_c, 160), 3)` at 160 mmHg. The drug is more
protective, in relative terms, against a higher blood pressure — the exposure-mediator
interaction built into the cohort. Drop the interaction term and the risk-ratio CDE
collapses to a single value, `r round(cde_rr(out_add_c, 130), 3)`, whatever `m`: a model
with no product term can only express a constant multiplicative drug effect, so it
cannot represent an `m`-dependent ratio even when the truth has one.

On the **risk-difference** scale the CDE depends on `m` in either model, but for
different reasons, so it is ambiguous evidence. Even without an interaction, a constant
risk ratio applied to a baseline that *rises* with blood pressure averts a larger
absolute amount at higher blood pressure — the arithmetic Chapter 16 develops. The
interaction adds to this a genuine change in the *relative* effect. So `m`-dependence on
the difference scale appears with or without a true interaction, whereas `m`-dependence
on the ratio scale is the signature of the interaction itself. Reading a controlled
direct effect therefore requires naming the scale and asking whether the model was
allowed to carry the interaction at all.

## Exercise 5 — what randomisation does and does not buy

Randomising the drug makes treatment independent of every baseline variable. That
secures two of the four identification conditions:

- **Condition 1** (no unmeasured treatment-outcome confounding): held, because the
  drug is independent of all common causes of treatment and stroke.
- **Condition 3** (no unmeasured treatment-mediator confounding): held, for the same
  reason — the drug is independent of all common causes of treatment and blood
  pressure.

It does **not** secure the other two:

- **Condition 2** (no unmeasured mediator-outcome confounding): not held. The trial
  randomises the *drug*, not the *blood pressure*. On-treatment blood pressure is still
  reached through each patient's severity, adherence, diet and physiology, any of which
  may also affect stroke. These confound the blood-pressure-to-stroke relationship just
  as `severity` does in the cohort, and randomising the drug does nothing to them.
- **Condition 4** (no treatment-induced mediator-outcome confounding): not held by
  design either, and untestable; the drug might change some variable that then confounds
  the blood-pressure-to-stroke relationship.

So the conclusion is not justified. Adjusting for on-treatment blood pressure in a
randomised trial is the very move that opens the collider path of Exercise 3: the
residual drug-stroke association the trialist reads as a "direct effect through another
route" can be produced entirely by unmeasured mediator-outcome confounding, with no
genuine direct effect at all. This is the central result of Robins and Greenland —
direct and indirect effects are not separately identified when only the exposure is
randomised. Randomisation buys the *total* effect cleanly; the *decomposition* still
rests on observational assumptions about the mediator, and those assumptions must be
argued for and probed by sensitivity analysis (Chapter 19), not assumed away by the
design.
