```{r setup, include=FALSE}
#| cache: false
source("_setup.R")
source("R/simulate_cohort.R")
set.seed(2024)
```

# Solutions to Chapter 17 exercises {.unnumbered}

::: {.callout-note appearance="simple"}
Worked solutions for the instrumental-variables chapter. Self-contained: it rebuilds the
cohort and the chapter's helpers below, so it can be rendered on its own. Not part of the
book build.
:::

```{r recreate}
#| code-fold: false
df <- simulate_cohort(n = 50000, seed = 2024)
o  <- attr(df, "oracle"); truth <- cohort_truth(df)

# the chapter's two ingredients, as functions of a data frame
first_stage <- function(d) mean(d$drug[d$pref == 1])   - mean(d$drug[d$pref == 0])
wald        <- function(d) (mean(d$stroke[d$pref == 1]) - mean(d$stroke[d$pref == 0])) /
                            first_stage(d)
```

## Exercise 1 — weaken the instrument

The strength of the instrument is the coefficient `d_pref` in the treatment model. We
shrink it, re-simulate, and recompute the first stage, the Wald estimate, and a bootstrap
interval at each strength.

```{r ex1}
#| code-fold: false
weak_iv <- function(d_pref, reps = 500) {
  p <- default_params(); p$d_pref <- d_pref
  d <- simulate_cohort(n = 50000, seed = 2024, params = p)
  set.seed(1)
  bt <- replicate(reps, { i <- sample(nrow(d), replace = TRUE); wald(d[i, ]) })
  tibble(d_pref = d_pref, first_stage = first_stage(d), Wald = wald(d),
         lo = quantile(bt, .025), hi = quantile(bt, .975), CI_width = hi - lo)
}
map_dfr(c(1.30, 0.80, 0.40, 0.20), weak_iv) |>
  kbl(digits = 3, caption = "As the instrument weakens, the first stage shrinks and the interval explodes.") |>
  kable_styling(full_width = FALSE)
```

As `d_pref` falls, the first stage shrinks from about 0.22 to under 0.04, and the
bootstrap interval widens from a width near 0.03 to over 0.2 — by the weakest setting it
spans zero, so the sign of the effect is no longer identified. The Wald estimate's
variance scales roughly with one over the squared first stage, because the first stage is
the denominator: dividing the noisy intention-to-treat contrast by a small number
amplifies its sampling error. This is the **weak-instrument** problem. An instrument can
satisfy every assumption and still be useless if it moves too little treatment, and a
weak first stage also magnifies any bias from a violation of exclusion (Exercise 3). The
point estimate drifts a little too, because changing `d_pref` changes which patients are
compliers and hence the subgroup the LATE refers to.

## Exercise 2 — the first stage is the complier proportion

```{r ex2}
#| code-fold: false
c(observed_first_stage = first_stage(df),
  mean_D1_minus_D0     = mean(o$D1) - mean(o$D0),
  P_complier           = mean(o$D1 == 1 & o$D0 == 0),
  P_defier             = mean(o$D1 == 0 & o$D0 == 1))
```

Because treatment equals `D1` when `pref = 1` and `D0` when `pref = 0`, the first stage is
$E[D_1] - E[D_0]$ up to the sampling split of the instrument. Writing it out,
$$
E[D_1] - E[D_0] = P(D_1 = 1) - P(D_0 = 1) = P(\text{complier}) - P(\text{defier}),
$$
because the only people who differ between "treated if encouraged" and "treated if not"
are the compliers (who add to $E[D_1]$) and the defiers (who subtract). With monotonicity
there are no defiers, so the first stage equals the complier proportion —
`r round(mean(o$D1 == 1 & o$D0 == 0), 3)` here. The observed first stage,
`r round(first_stage(df), 3)`, differs from it only because the instrument splits the
sample into two halves and each `mean` is taken over a different half. A defier would
**subtract** from the first stage: defiers and compliers move treatment in opposite
directions, so without monotonicity the first stage understates how many people the
instrument actually moves, and the Wald ratio becomes a difference-weighted blend of
complier and defier effects rather than a clean complier average.

## Exercise 3 — vary the leak

The exclusion violation in the invalid variant is the parameter `leak_pref`, the direct
effect of preference on stroke risk. We sweep it and track the Wald estimate against the
true complier effect.

```{r ex3}
#| code-fold: false
leak_run <- function(lk) {
  p <- default_params(); p$leak_pref <- lk
  d  <- simulate_cohort(n = 50000, seed = 2024, params = p, invalid_iv = TRUE)
  ox <- attr(d, "oracle")
  tibble(leak = lk, Wald = wald(d),
         true_LATE = mean((ox$risk1 - ox$risk0)[ox$D1 == 1 & ox$D0 == 0]))
}
sweep <- map_dfr(seq(0, 0.30, by = 0.025), leak_run)
cross <- approx(sweep$Wald, sweep$leak, xout = 0)$y    # leak at which Wald hits zero
```

```{r ex3-plot}
#| echo: false
#| fig-cap: "The Wald estimate against the size of the exclusion violation. The true complier effect (red) is roughly stable and protective; the Wald estimate (blue) climbs with the leak, crosses zero, and turns positive. A leak of about 0.11 on the log-risk scale is enough to nullify the apparent effect."
#| fig-width: 7
#| fig-height: 3.6
ggplot(sweep, aes(leak)) +
  geom_hline(yintercept = 0, linewidth = 0.3, colour = "grey60") +
  geom_line(aes(y = Wald, colour = "Wald estimate"), linewidth = 0.8) +
  geom_point(aes(y = Wald, colour = "Wald estimate")) +
  geom_line(aes(y = true_LATE, colour = "true complier effect"), linewidth = 0.8) +
  geom_vline(xintercept = cross, linetype = "dashed", colour = "grey50") +
  scale_colour_manual(values = c("Wald estimate" = "#2c6fbb", "true complier effect" = "#b03030")) +
  labs(x = "exclusion violation (leak_pref, log-risk scale)", y = "risk difference",
       colour = NULL) +
  theme_minimal(base_size = 12) + theme(legend.position = "bottom")
```

The Wald estimate crosses zero at a leak of about `r round(cross, 3)`, while the true
complier effect stays near `r round(sweep$true_LATE[1], 3)` throughout. A direct effect of
preference on stroke of that size is a relative risk of only about
`r round(exp(cross), 2)` — a `r round((exp(cross)-1)*100)`% direct effect of which
physician you saw — yet it is enough to wipe out the apparent benefit of the drug. The
violation is small because it is amplified: the leaked contribution to the
intention-to-treat numerator is divided by the modest first stage, so a minor breach of
an untestable assumption produces a major shift in the estimate. This is the calculation a
**sensitivity analysis** (Chapter 19) formalises — rather than assuming exclusion holds,
ask how large a violation would have to be to overturn the conclusion, and judge whether a
violation that large is plausible. Here it is not large at all, so the IV conclusion is
fragile.

## Exercise 4 — when the complier effect equals the population effect

LATE and ATE differ only because the compliers are a selected subgroup *and* the effect
varies across patients. Remove either ingredient and they coincide. A small self-contained
simulation makes this visible: an unmeasured confounder `U`, a randomly assigned
instrument `Z`, a monotone treatment rule, and a continuous outcome whose treatment effect
is either constant or `U`-dependent.

```{r ex4}
#| code-fold: false
set.seed(1); n <- 2e5
U   <- rnorm(n); Z <- rbinom(n, 1, 0.5)
eta <- -0.2 + 1.0 * U + rlogis(n)               # latent treatment index
D0  <- as.integer(eta > 0); D1 <- as.integer(eta + 1.5 > 0)   # Z shifts the index
D   <- ifelse(Z == 1, D1, D0); complier <- D1 == 1 & D0 == 0
meanU_comp <- mean(U[complier])                  # the compliers' confounder distribution
iv_slope <- function(Y) (mean(Y[Z == 1]) - mean(Y[Z == 0])) /
                        (mean(D[Z == 1]) - mean(D[Z == 0]))

# homogeneous effect: the same tau for everyone
Yc <- 1 + 1.5 * U + (-2) * D + rnorm(n)
# heterogeneous effect: tau varies with the confounder U
tau <- -2 + 1.5 * U
Yh  <- 1 + 1.5 * U + tau * D + rnorm(n)

rbind(
  homogeneous   = c(ATE = -2,         LATE = -2,                 Wald = iv_slope(Yc)),
  heterogeneous = c(ATE = mean(tau),  LATE = mean(tau[complier]), Wald = iv_slope(Yh)))
```

With a constant treatment effect, the average effect is the same in every subgroup, so it
makes no difference that compliers are special: the ATE, the LATE, and the Wald estimate
all land at `r -2`. With a `U`-dependent effect, the compliers — who have a particular
distribution of `U` (here a mean of about `r round(meanU_comp, 2)`, against zero in the
population) — have a different average effect from everyone, and the Wald estimate tracks
the complier effect, not the ATE. Effect heterogeneity is the necessary ingredient: when
it is absent, the locality of the LATE is harmless; when it is present, IV answers a
question about the marginal patients that need not generalise to anyone else.

## Exercise 5 — distance to hospital as an instrument

Take the instrument `Z` to be distance to the nearest specialist hospital, the treatment
`A` to be receipt of the procedure, and `Y` the health outcome.

- **Relevance** — distance must affect whether the procedure is received: patients living
  far from a specialist centre are less likely to undergo it. This is **examinable** in the
  data, as the first stage (the procedure rate by distance). It could fail if referral
  pathways send everyone to the centre regardless of distance, leaving a weak instrument.
- **Exclusion** — distance must affect the outcome *only* through the procedure. This
  **cannot be checked**. It fails if distance proxies for rurality, which affects outcomes
  through other routes: slower emergency response, less access to follow-up care, different
  background health services. Then distance reaches the outcome by paths that bypass the
  procedure.
- **Independence** — distance must share no common cause with the outcome. This **cannot be
  fully checked**, though one can probe it by testing whether measured prognostic factors
  are balanced across distance (a necessary, not sufficient, condition). It fails if sicker
  or poorer populations are systematically located nearer to, or farther from, hospitals —
  the urban–rural health gradient is a common cause of both distance and outcome.
- **Monotonicity** (for the LATE interpretation) — living closer never makes a patient
  *less* likely to receive the procedure. Usually plausible, but it could fail if, say, a
  nearby low-volume hospital deters referral that a more distant high-volume centre would
  accept.

So **relevance** is testable from the first stage, and **independence** can be partly
probed through balance of measured covariates; **exclusion** and the unmeasured part of
**independence** can only be argued, by reasoning about whether distance plausibly affects
the outcome other than through the procedure. As Exercise 3 showed, those untestable
assumptions are the ones whose mild violation can overturn the estimate, which is
why an IV analysis stands or falls on the substantive case for the instrument, not on any
statistic the data can provide.
