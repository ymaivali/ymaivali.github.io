```{r setup, include=FALSE}
#| cache: false
source("_setup.R")
set.seed(2024)
```

# Solutions to Chapter 18 exercises {.unnumbered}

::: {.callout-note appearance="simple"}
Worked solutions for the quasi-experimental chapter. Each exercise extends one of the
chapter's mini-simulations; the code is self-contained. Not part of the book build.
:::

## Exercise 1 — front-door with a confounded mediator

Add an arrow from the unmeasured confounder `U` into the mediator `M`.

```{r ex1}
#| code-fold: false
set.seed(1); n <- 1e5
U <- rnorm(n)
A <- rbinom(n, 1, plogis(1.2 * U))
M <- 2 * A + 1.5 * U + rnorm(n)        # U -> M added (was absent in the chapter)
Y <- 1.5 * M + 3 * U + rnorm(n)        # still no direct A -> Y

beta  <- coef(lm(M ~ A))["A"]          # "effect of A on M"
gamma <- coef(lm(Y ~ M + A))["M"]      # "effect of M on Y given A"
c(truth = 2 * 1.5, beta_hat = beta, gamma_hat = gamma, front_door = beta * gamma)
```

The front-door estimate, `r round(beta*gamma, 1)`, no longer recovers the true effect of 3 —
it is now badly wrong. The true effect is unchanged at `r 2*1.5`, because the *structural*
coefficients (2 for `A -> M`, 1.5 for `M -> Y`) are unchanged; what broke is the
identification, not the world.

Adding `U -> M` violates two of the front-door conditions at once. First, the path
`A <- U -> M` is now an unblocked back-door from `A` to `M`, so the regression of `M` on `A`
is confounded and `beta_hat` (`r round(beta,2)`) overshoots the true 2. Second,
`M <- U -> Y` is now an unblocked back-door from `M` to `Y` that conditioning on `A` does not
close, so `gamma_hat` (`r round(gamma,2)`) overshoots the true 1.5. Both clean pieces the
criterion relied on are contaminated, and their product compounds the error. This is why the
mediator must be untouched by the confounder: the front-door criterion buys identification
precisely by assuming `U` does not reach `M`, and the assumption is doing real work.

## Exercise 2 — calibrate with a negative control

Vary the quality of the measured proxy `Uobs` and watch the negative-control association
against the residual bias in the real estimate.

```{r ex2}
#| code-fold: false
set.seed(2); n <- 1e5
U <- rnorm(n); A <- rbinom(n, 1, plogis(1.0 * U))
Y <- 0.5 * A + 2 * U + rnorm(n)        # true A -> Y = 0.5 ; U -> Y coefficient 2
N <- 2 * U + rnorm(n)                  # negative control: U -> N coefficient 2 ; no A -> N

calibrate <- function(noise) {
  Uobs <- U + rnorm(n, 0, noise)       # noisier proxy = worse adjustment
  tibble(noise = noise,
         nco_assoc  = coef(lm(N ~ A + Uobs))["A"],          # residual negative-control signal
         resid_bias = coef(lm(Y ~ A + Uobs))["A"] - 0.5)    # residual bias in the real estimate
}
cal <- map_dfr(c(0.01, 0.2, 0.4, 0.7, 1.0, 1.5, 2.5, 4), calibrate)
```

```{r ex2-plot}
#| echo: false
#| fig-cap: "Residual bias in the A-on-Y estimate against the residual negative-control association, as the proxy degrades from near-perfect (bottom left) to useless (top right). The points lie on the 45-degree line: the negative control reports the bias almost one-for-one, because the confounder acts on N and on Y with equal strength here."
#| fig-width: 5.2
#| fig-height: 4.2
ggplot(cal, aes(nco_assoc, resid_bias)) +
  geom_abline(slope = 1, intercept = 0, linetype = "dashed", colour = "grey60") +
  geom_point(size = 2.4, colour = "#2c6fbb") +
  labs(x = "negative-control association (A on N)",
       y = "residual bias (A on Y, vs truth 0.5)") +
  coord_equal() + theme_minimal(base_size = 12)
```

The negative control tracks the real bias almost perfectly: each point sits on the
45-degree line, from near-zero when the proxy is sharp to about
`r round(max(cal$nco_assoc),1)` when it is useless. The tracking is one-to-one here for a
specific reason — the confounder `U` acts on the negative control and on the real outcome
with the same coefficient (2). In general the negative-control association equals the bias
only up to the *ratio* of the confounder's effect on `N` versus on `Y`; calibrating the bias
away (rather than just detecting it) requires assuming that ratio, which is the idea behind
proximal causal inference. The exercise shows the optimistic case: when the control is a
faithful stand-in, its visible association is a direct meter of the invisible bias.

## Exercise 3 — bandwidth in regression discontinuity

The bias–variance trade-off depends on the estimator. Compare a **local-constant** estimate
(difference of means within the window) with the chapter's **local-linear** estimate (a
slope fitted on each side), at four bandwidths.

```{r ex3}
#| code-fold: false
set.seed(3); n <- 3e5
X <- runif(n, 100, 180); cutoff <- 140; A <- as.integer(X >= cutoff); tau <- -3
Y <- 0.2 * X + tau * A + rnorm(n, 0, 5)            # linear confounding

local_constant <- function(h) {
  s <- abs(X - cutoff) <= h
  est <- mean(Y[s & A == 1]) - mean(Y[s & A == 0])
  se  <- sqrt(var(Y[s & A==1])/sum(s & A==1) + var(Y[s & A==0])/sum(s & A==0))
  tibble(bandwidth = h, estimate = est, se = se)
}
local_linear <- function(h) {
  d <- data.frame(Y, A, Xc = X - cutoff)[abs(X - cutoff) <= h, ]
  m <- lm(Y ~ A + Xc + A:Xc, data = d)
  tibble(bandwidth = h, estimate = coef(m)["A"], se = summary(m)$coef["A","Std. Error"])
}
bind_rows(
  map_dfr(c(2, 5, 10, 20), local_constant) |> mutate(estimator = "local constant"),
  map_dfr(c(2, 5, 10, 20), local_linear)   |> mutate(estimator = "local linear")) |>
  select(estimator, bandwidth, estimate, se) |>
  kbl(digits = 3, caption = "RDD estimate and its standard error by bandwidth and estimator (truth = -3).") |>
  kable_styling(full_width = FALSE)
```

The local-constant estimator shows the trade-off in its rawest form. At the narrowest
bandwidth it is close to the truth but imprecise; as the window widens, the standard error
falls but the estimate drifts — from about −2.6 at a bandwidth of 2 to a *positive* value at
20, because a wider window pulls in treated patients with systematically higher blood
pressure, and the smooth confounding masquerades as a treatment effect. Narrow means low
bias and high variance; wide means low variance and high bias.

The local-linear estimator escapes most of it. By fitting a slope on each side, it absorbs
the linear confounding, so the estimate stays near −3 at every bandwidth while the standard
error still falls as the window grows — the best of both. This is why local-linear (or
higher-order local) regression is the standard for regression discontinuity: it removes the
first-order bias, leaving only a smaller, second-order bias from any *curvature* in the
confounding function, which is what then limits how wide a bandwidth one should use.

## Exercise 4 — a pre-trend test for difference-in-differences

Add a pre-treatment period and check whether parallel pre-trends guarantee the assumption in
the treatment period. Treatment occurs between periods 0 and 1; period −1 is an extra
pre-treatment observation.

```{r ex4}
#| code-fold: false
set.seed(4); n <- 50000
a <- 10; grp <- 5; trend <- 3; tau <- -4; shock <- 3
m <- function(mu) mean(rnorm(n, mu, 2))

control <- c(p_1 = m(a), p0 = m(a + trend), p1 = m(a + 2*trend))   # parallel trend throughout

# Scenario A: parallel pre-trends, but a concurrent non-treatment shock hits the treated at p1
treatA  <- c(p_1 = m(a+grp), p0 = m(a+grp+trend), p1 = m(a+grp+2*trend + tau + shock))
# Scenario B: the treated group is on a steeper trajectory in every period
treatB  <- c(p_1 = m(a+grp), p0 = m(a+grp+trend+2), p1 = m(a+grp+2*(trend+2) + tau))

did <- \(tr) unname((tr["p1"] - tr["p0"]) - (control["p1"] - control["p0"]))    # periods 0,1
pre <- \(tr) unname((tr["p0"] - tr["p_1"]) - (control["p0"] - control["p_1"]))  # periods -1,0

pre_A <- pre(treatA); did_A <- did(treatA)
pre_B <- pre(treatB); did_B <- did(treatB)
rbind(`A: parallel pre + shock`  = c(pre_trend = pre_A, DiD = did_A),
      `B: divergent throughout`  = c(pre_trend = pre_B, DiD = did_B))
```

In scenario B the treated group was already pulling away before treatment: the pre-trend
difference is about `r round(pre_B,1)`,
a clear failure that warns the analyst off — the difference-in-differences estimate of about
`r round(did_B,1)` is duly
suspect against the truth of −4. This is the test working.

Scenario A is the trap. The pre-trend difference is about
`r round(pre_A,1)` — the groups
moved in parallel before treatment, so the test *passes*. Yet the difference-in-differences
estimate is about
`r round(did_A,1)`, far from the
true −4, because a concurrent shock hit the treated group at the same moment as the
treatment. A pre-trend test examines the *past*; the parallel-trends assumption is a claim
about the counterfactual *future*, which can break for any reason that coincides with the
treatment timing. Passing the test is reassuring but not sufficient — just the kind of
untestable residual the sensitivity analysis of Chapter 19 is built to probe.

## Exercise 5 — the identifying assumption of each design

| Design | The assumption that identifies the effect | Examinable in data? | A fitting setting |
|---|---|---|---|
| **Front door** | A measured mediator carries the *entire* effect (no direct path), and is unconfounded with both exposure and outcome. | Largely no — the absence of a direct path and of mediator confounding is argued from subject knowledge. | Exposure acting through a single well-measured biological intermediate, with unmeasured confounding of exposure and outcome. |
| **Negative control** | The control variable has a *true zero* effect and shares the exposure's confounding. | The zero effect is assumed (argued); the association it then shows is data. | Detecting confounding by, e.g., an outcome that could not plausibly be caused by the exposure but shares its selection into treatment. |
| **Regression discontinuity** | Potential outcomes are *continuous* at the cutoff: nothing else changes there, and the running variable is not manipulated. | Partly — manipulation (density at the cutoff) and covariate continuity can be tested; outcome continuity itself cannot. | A treatment assigned by a sharp threshold on a continuous score (a lab-value or age eligibility rule). |
| **Difference-in-differences** | *Parallel trends*: absent treatment, the groups would have changed by the same amount. | Partly — pre-treatment trends can be checked (necessary, not sufficient), as Exercise 4 showed. | A policy reaching some units at a known time and sparing comparable others (a staggered regional roll-out). |

Across the four, the identifying assumption is at best *partly* examinable, and never fully:
front-door and negative-control assumptions are essentially arguments about structure;
regression discontinuity and difference-in-differences offer partial diagnostics
(manipulation tests, pre-trends) that can reveal a violation but cannot confirm the
assumption. In every case the credibility of the estimate rests on the substantive case for
the design, which is why the next chapter turns to asking how far each assumption can bend
before the conclusion gives way.
