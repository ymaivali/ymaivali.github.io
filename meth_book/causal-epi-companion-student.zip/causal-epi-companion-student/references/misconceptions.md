# Misconceptions, with the question that surfaces each one

Use one at a time: the one the reader's message reveals. Ask the question, wait, resolve in a
line or two, point to the chapter. Teacher mode may state the resolution directly.

## Part I and II: thinking and probability

- **"Probability is a frequency."** Ask: what is the probability that a named patient has the
  disease, before the test result? Resolve: probability is a degree of plausibility given
  what is known; frequencies are one kind of evidence about it. Chapters 8 and 9.
- **"A prior is a bias."** Ask: what does a flat prior on a logit scale say about the risk?
  Resolve: every analysis has a prior; the choice is between a stated one and a hidden one.
  Chapters 10 and 23.
- **"The p value is the probability the null is true."** Ask: what is being conditioned on
  in a p value, and what would you need to turn it round? Resolve: P(data or more extreme |
  H0), and Bayes' theorem needs a prior. NHST appendix.
- **"The posterior is always narrower than the prior."** Ask: what happens when the data
  disagree with the prior? Resolve: it can widen; the likelihood adds information about
  location, not always about spread. Chapter 10.

## Part III: counterfactuals and graphs

- **"We could measure this patient's own causal effect."** Ask: how many of the patient's
  two potential outcomes does the world show you? Resolve: one; individual effects are
  unknowable, so the target is an average. Chapter 11.
- **"The treated did worse, so the treatment harms."** Ask: were the treated and the
  untreated the same kind of patient before treatment? Resolve: confounding by indication;
  in the cohort the crude risk ratio points the wrong way. Chapters 11 and 13.
- **"More adjustment is safer."** Ask: could this covariate lie on the path from treatment
  to outcome, or be a common effect of both? Resolve: mediators and colliders create bias
  when adjusted for; the DAG chooses. Chapter 12.
- **"Balanced covariates mean no confounding."** Ask: what does the balance table say about
  the covariates you did not measure? Resolve: nothing; exchangeability is an assumption
  probed by sensitivity analysis. Chapters 11 and 20.
- **"Positivity is a sample-size problem."** Ask: is there a stratum that can never be
  treated, or one that merely was not in this sample? Resolve: structural vs practical
  violation; the estimator decides how much the practical one bites. Chapter 11.
- **"Randomisation makes the arms identical."** Ask: identical in this sample, or comparable
  in expectation? Resolve: exchangeability in expectation. Chapter 4.
- **"Immortal time is a technicality."** Ask: when does each patient's follow-up start, and
  when is their treatment group decided? Resolve: time zero must be the same moment as
  assignment; the target-trial protocol forces this. Chapter 14.
- **"Adjust for the baseline value of a time-varying confounder and you are done."** Ask:
  does the confounder at visit 2 depend on treatment at visit 1? Resolve: treatment-confounder
  feedback needs g-methods, not regression adjustment. Chapter 15.

## Part IV: beyond the back door

- **"Control for the mediator to get the direct effect."** Ask: is there a common cause of
  the mediator and the outcome, and what happens to the treatment–outcome path when you
  condition on the mediator? Resolve: collider bias through the mediator; mediation needs
  its own identification assumptions. Chapter 16.
- **"No significant product term, no interaction."** Ask: on which scale is the product
  term an interaction, and what does a constant risk ratio do to the risk difference when
  the baseline differs? Resolve: interaction is scale-dependent; report both scales.
  Chapter 17.
- **"An instrument only has to be correlated with treatment."** Ask: can the instrument reach
  the outcome by any path other than treatment, and does it share a cause with the outcome?
  Resolve: relevance, exclusion and independence, and the estimand is local. Chapter 18.
- **"The E-value tells you whether confounding is present."** Ask: what would an unmeasured
  confounder have to look like to explain the result away? Resolve: sensitivity analysis
  describes robustness, it does not detect confounding. Chapter 20.

## Part V: regression

- **"exp(β) is the effect."** Ask: at what values of the other covariates, and for which
  patient? Resolve: a conditional quantity on the link scale; report the standardised
  contrast. Chapters 21, 22 and 25.
- **"The other coefficients are the effects of those variables."** Ask: was the adjustment set
  chosen for that variable? Resolve: the Table 2 fallacy. Chapter 22.
- **"An odds ratio of 2 doubles the risk."** Ask: start at a baseline risk of 30 percent;
  what risk does an odds ratio of 2 give? Resolve: 46 percent, a risk ratio of about 1.5.
  Chapters 11 and 25.
- **"Adjusting changed the odds ratio, so there was confounding."** Ask: what happens to a
  logistic coefficient under randomisation when a strong outcome predictor is added?
  Resolve: it moves away from 1 without any confounding; non-collapsibility. Chapter 25.
- **"Use a log link to get a risk ratio."** Ask: what does standardising a logistic fit to
  the ratio of averaged risks give you? Resolve: a risk ratio; the link is a functional-form
  choice, not the route to a measure. Chapter 25.
- **"Compare links with `loo` and keep the best."** Ask: what does the Poisson working model
  put probability on that a 0/1 outcome never takes, and which outcomes does `loo` score?
  Resolve: the comparison is mechanical against the Poisson, and blind to counterfactual
  predictions under poor overlap. Chapter 25.
- **"Pick the adjustment set by `loo` or by AIC."** Ask: does a mediator predict the outcome
  well? Resolve: yes, so fit-based selection admits it; the DAG decides. Chapters 22 and 23.
- **"The hazard ratio is the treatment effect."** Ask: who is still in the risk set at time
  t in each arm? Resolve: survivors, selected by treatment; report survival or
  cumulative-incidence differences. Chapters 11 and 26.
- **"A good AUC means the model is right."** Ask: what does discrimination say about
  identification? Resolve: nothing; a consequence of the outcome raises the AUC and destroys
  every causal reading. Chapters 25 and 27.
- **"Complete-case analysis is unbiased if data are MCAR."** Ask: where does the missingness
  node attach in the DAG, and what does conditioning on being complete open? Resolve: the
  graph, not the label, decides. Chapter 30.
- **"Random effects are for when you have repeated measures."** Ask: what does partial pooling
  do to a small cluster's estimate, and what is the population-level contrast? Resolve:
  shrinkage; conditional and marginal effects differ for non-linear links. Chapter 28.
