# Notation, as the book writes it

Keep to these symbols so that an explanation lines up with the page the reader is looking at.

## Potential outcomes and identification

- `A` treatment or exposure, `A = 1` treated, `A = 0` untreated; the cohort's `drug`.
- `Y` observed outcome; `Y(a)`, `Y(1)`, `Y(0)` potential outcomes; `Y_i(a)` for unit i.
- `L` the covariates or adjustment set; `L = l` one stratum.
- `E[·]` expectation; for a 0/1 outcome a risk.
- `ATE = E[Y(1)] − E[Y(0)]`; `ATT = E[Y(1) − Y(0) | A = 1]`; `ATU` likewise among the untreated.
- `RD`, `RR`, `OR`, `HR` risk difference, risk ratio, odds ratio, hazard ratio; `NNT = 1/|RD|`.
- `do(A = a)`, `P(Y | do(A = a))` intervention; `E[Y(a)] = E[Y | do(A = a)]`.
- g-formula: `E[Y(a)] = Σ_l E[Y | A = a, L = l] · P(L = l)`.
- Exchangeability `Y(a) ⊥ A`; conditional exchangeability `Y(a) ⊥ A | L`; positivity
  `0 < P(A = a | L = l) < 1` wherever `P(L = l) > 0`; consistency `Y = Y(A)`.
- Mediation: `M` mediator; `Y(a, m)`; natural direct and indirect effects; controlled direct effect.
- Instruments: `Z` with the exclusion restriction `Z → Y` only through `A`; the cohort's `pref`.
- Time-varying: `A_k`, `L_k` at visit k; `Ā_k` history; `Y(ā)`.

## Probability and Bayes

- `P(H | d, I)` posterior of hypothesis H given data d and background I; the hypothesis
  space is `𝓗`.
- Odds form: posterior odds = prior odds × likelihood ratio; **weight of evidence**
  `W = log(likelihood ratio)`; log posterior odds = log prior odds + W.
- Prior predictive and posterior predictive distributions; `p(ỹ | y)`.
- Credible interval, highest-density interval (HDI) when stated.

## Regression and GLMs

- Linear predictor `η_i = α + β_1 x_i1 + … + β_K x_iK`; link `g(μ_i) = η_i`; mean `μ_i = g⁻¹(η_i)`.
- Identity link: coefficients in outcome units (a risk difference for a 0/1 outcome).
- Log link: `exp(β)` is a risk or rate ratio; `offset(log(t))` turns a count into a rate.
- Logit link: `exp(β)` is a conditional odds ratio; `logit(μ) = log{μ/(1 − μ)}`.
- Splines `s(x)`, interactions `a * b` (a product term on the link scale only).
- `σ` residual sd; `φ` precision (beta); `shape` (negative binomial).
- Multilevel: `(1 | group)` random intercept; `(x | group)` random slope; partial pooling.

## brms and marginaleffects idioms

- `brm(y ~ x, family = ..., prior = ..., data = ..., file = "models/...", file_refit = "on_change")`.
- `prior(normal(0, 1), class = "b")`; `default_prior()` (alias of `get_prior()`).
- `posterior_epred()` expected values; `posterior_predict()` new outcomes; `as_draws_df()`.
- `avg_comparisons(m, variables = "drug")` risk difference; `comparison = "ratioavg"` risk
  ratio (ratio of averaged risks, not the average of ratios); `comparison = "lnoravg"` log
  marginal odds ratio; `by = "diabetes"` stratum-specific contrasts; `avg_predictions()`.
- `loo(m)`, `loo_compare()`, `pp_check(m, type = "...")`, `brms::rhat()`, `brms::nuts_params()`.
- `y | weights(w)`, `y | se(se)`, `y | mi(sdy = s)`, `y | trials(n)`, `y | cens(c)`.
