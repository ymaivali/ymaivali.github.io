# The book's conventions

*The Bayesian Way to Causal Epidemiology* (Ülo Maiväli) takes positions that differ from
the average of what is written about epidemiological analysis. A reader who asks about
these topics should get the book's answer, with the reason, and with the difference from
the common answer named. Do not correct the reader back toward convention. Where the book
is silent, say so and answer plainly, labelled as outside the book.

## The workflow, in the order the book teaches it

1. **State the estimand before touching data.** A causal question is a contrast of
   potential outcomes in a named population: the average treatment effect
   E[Y(1)] − E[Y(0)], or the effect in the treated, on a stated scale, at a stated time
   horizon. Chapter 11 (potential outcomes).
2. **Draw the DAG and read the adjustment set off it.** Confounders are common causes of
   treatment and outcome that block every back-door path. Mediators and colliders are not
   adjusted for; adjusting for them creates bias. The set is never chosen by model fit,
   change-in-estimate, stepwise selection or "adjust for everything". Chapter 12 (DAGs).
3. **Frame an observational treatment question as a target trial** where one applies:
   eligibility, time zero, treatment strategies, follow-up, estimand. Chapter 14.
4. **Stratify and standardise before regressing.** Regression is standardisation with a
   model in the middle; the causal logic lives in the stratification step. Chapter 13.
5. **Fit a Bayesian model with brms** with priors reasoned about in the units of the
   predictors, a prior predictive check, MCMC diagnostics (R-hat, divergences), and
   posterior predictive checks. Model fit is compared with `loo` only within a fixed
   adjustment set: `loo` ranks functional forms, it cannot audit the covariates, and it
   scores only the outcomes that were observed. Chapter 23 (workflow).
6. **Report every effect as a contrast of model predictions**, standardised over the
   covariate distribution with `marginaleffects` (`avg_comparisons()`, `avg_predictions()`,
   `comparison = "ratioavg"` for a risk ratio), carrying the posterior through. Never read a
   coefficient as the effect. Chapters 21 to 25 and 29 (g-computation).
7. **Probe unmeasured confounding with sensitivity analysis** (bounding factor, E-value,
   negative controls), never claim exchangeability from covariate balance. Chapter 20.
8. **Handle missing data from the DAG**: the missingness mechanism is a node; row deletion,
   weighting and imputation are judged by what the graph says. Chapter 30.

## Positions that differ from the common answer

| Topic | Common answer | The book | Why |
|---|---|---|---|
| Effect measure | odds ratio (logistic regression), hazard ratio (Cox) | **risk difference and risk ratio**, standardised; survival or cumulative-incidence differences; restricted mean survival time | OR and HR are non-collapsible and not on the probability scale a decision uses; a hazard ratio conditions on survival, a post-treatment variable |
| Reading a coefficient | exp(β) is the effect | the effect is a **standardised contrast of predictions**; the coefficient is conditional, on the link scale, and for covariates other than the exposure it is not an effect of anything (Table 2 fallacy) | non-collapsibility; adjustment changes what a logistic coefficient estimates even under randomisation |
| Binary outcome model | logistic regression | **log link on the cohort's stroke outcome, as a Poisson working model** (`family = poisson()` on 0/1; the log-binomial does not sample); logit where the outcome is common, for prediction, and for case-control or matched designs; identity only as the linear probability model of a randomised comparison | the cohort's mechanism is multiplicative in risk; the link is a functional-form choice, not a choice of what to report |
| Choosing the link by `loo` | compare families and pick the best | `loo` chooses the **likelihood family** (Poisson vs negative binomial) and the covariate specification; a Poisson working model cannot enter a `loo` comparison against a Bernoulli model; under poor overlap `loo` is blind to the counterfactual predictions the estimand needs | it scores the outcome that was observed |
| Covariate selection | change-in-estimate, stepwise, p values, `loo` | the **DAG**, and nothing else | any data-driven rule will admit mediators and colliders, which predict well |
| Interaction | a non-significant product term means no interaction | interaction is **scale-dependent**; a product term is an interaction on the link scale only; report stratum-specific effects on both scales | a constant risk ratio implies an additive interaction wherever baseline risk differs |
| Randomised trial analysis | unadjusted, or adjusted odds ratio | adjust for prognostic covariates and report the **standardised** risk difference or ratio | adjustment changes the odds ratio's estimand, not its bias |
| Case-control study | "only the odds ratio is estimable" | what the odds ratio estimates depends on how controls were sampled (rate ratio under density sampling, risk ratio under case-cohort); known sampling fractions or an external baseline risk turn it back into risks; logistic regression is the analysis because its slopes are invariant to outcome-dependent sampling | Chapter 25 |
| Inference | p values, significance, confidence intervals | **posterior distributions and credible intervals**; no null hypothesis testing; the NHST appendix explains the machinery and why the book does not use it | probability is the logic of science (Part II) |
| Priors | flat, "objective" | **weakly informative priors reasoned in the units of the predictor**, checked by a prior predictive simulation | a flat prior on a logit or log scale is informative in the wrong direction |
| Missing data | complete-case analysis, or multiple imputation as default | mechanism drawn on the **DAG**; the method follows from where the missingness node attaches | MCAR/MAR/MNAR labels are less informative than the graph |
| Prediction vs causation | one regression does both | **different games**: a predictive model may include descendants of the outcome and is judged by calibration and discrimination on held-out data; a causal model may not, and is judged by identification | Chapter 27 |
| Causation | "no causation without manipulation" forbids questions about race, sex, obesity | the framework **disciplines** such questions into well-defined interventions or descriptive decompositions; it does not forbid them | Chapter 11 |
| The counterfactual model | a theory of what causation is | an **operational convenience** for reasoning about interventions; the metaphysics is a separate question (Chapter 5) | the book keeps this firewall |

## Terminology the book uses

- "risk ratio (often called the relative risk)": say **risk ratio**.
- **credible interval** for posterior intervals; "confidence interval" only for frequentist
  ones, and say which is meant.
- **p value**, unhyphenated; the book explains it and does not use it.
- **exchangeability** (not "ignorability"); **positivity**; **consistency**; **SUTVA**.
- **standardisation** = g-computation = the g-formula with a model in the middle.
- **estimand / estimator / estimate** kept apart.
- **Poisson working model**: `family = poisson()` fitted to a 0/1 outcome for a log-link risk model.
- **weight of evidence** = log likelihood ratio (Chapter 9); linear on the logit scale means
  evidence accumulates additively.
- British spelling: randomisation, modelled, standardisation, centre.

## The master cohort

Almost every chapter from Part III onward uses one simulated cohort, so a reader's code
can be recognised from its variables.

- `simulate_cohort(n = N_COHORT, seed = 2024)` with `N_COHORT = 50000`; `age_c <- (age - 62) / 10`.
  Variants take a parameter list: `simulate_cohort(n, seed, params = modifyList(default_params(), list(...)))`.
  The longitudinal version is `simulate_cohort_longitudinal(n = N_COHORT, seed = 2024)` (Chapters 14, 15, 29).
- Question: does a blood-pressure-lowering **drug** prevent **stroke** (0/1) in hypertensive patients?
- Variables: `drug` (treatment), `stroke` (outcome), `severity` (latent illness severity,
  confounder by indication), `age`, `diabetes` (confounder and effect modifier), `sbp`
  (systolic blood pressure, mediator), `pref` (prescriber preference, instrument),
  `hospitalised` (a consequence of the outcome; never in a causal model).
- Adjustment set for the total effect: the DAG's minimal set is `{severity, diabetes}`
  (`dagitty::adjustmentSets()` in Chapter 12); the book's standard outcome model adds
  `age_c`, a cause of the outcome whose inclusion is harmless and improves precision, so the
  fits read `stroke ~ drug + severity + age_c + diabetes`. Blood pressure is a mediator and
  stays out; `pref` is an instrument and stays out; `hospitalised` is a collider and never enters.
- The oracle (`attr(df, "oracle")`, `cohort_truth(df)`) reveals both potential outcomes.
  Truth: E[Y(0)] 6.8%, E[Y(1)] 4.1%, risk difference −0.0272, risk ratio 0.600, odds ratio
  0.583. The crude association points the other way, because the sicker patients get the drug.
- A randomised variant sets `d_sev = d_dm = d_pref = 0` in `default_params()` (the chapters call it `params_rct`).
- Models are cached under `models/` with `file = ..., file_refit = "on_change"`.
