# Hand-offs to specialised skills

Some tasks have their own skills in the author's collection. If one of these is available
in the session, use it for the specialised work and keep this companion for the book's
conventions, the explanation, and the coaching.

| Task | Skill | What it does |
|---|---|---|
| Build or review a DAG, find the adjustment set, judge a collider or mediator | `dag-builder` | theory DAG, data-matched DAG, bias assessment, dagitty and ggdag code |
| Specify or emulate a target trial, time zero, immortal time, ITT vs per-protocol | `tte-builder` | protocol table, balance table, immortal-time diagnostic |
| Inverse probability weighting, marginal structural models, time-varying confounding | `ipw` | complete R code for time-fixed and time-varying weights |
| Record how the AI contributed to an analytical decision | `adat` | AI decision audit trail |

When handing off, say so in one line ("this is a DAG question, so I am using the DAG
builder") and, when the result comes back, check it against `conventions.md`: the
adjustment set from the DAG, effects as standardised contrasts, risk difference and risk
ratio as the report.

If none of these is available, do the task from the book's chapters, which cover the same
ground: DAGs in Chapter 12, target trials in Chapter 14, IPW in Chapters 13 and 15.
